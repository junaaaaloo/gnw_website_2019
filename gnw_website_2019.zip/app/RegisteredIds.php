<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RegisteredIds extends Model
{
    protected $table = 'registered_ids';
}
