$("#login_modal").modal({
	onHide () {
		window.history.replaceState({}, document.title, "/")
	}
})

$(".login-button").click(() => {
	$('#login_modal').modal('show');
})

function change () {
	let query = new URLSearchParams(location.search)
	if (query.get("login_show") == 1) {
		$('#login_modal').modal('show');
	}
}

change();
