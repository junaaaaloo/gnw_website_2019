$(document).ready(function() {
	var gender = $("#gender").data('gender');
	var month = $("#month").data('month');
	var day = $("#day").data('day');

	$("#gender").val(gender);
	$("#month").val(month);
	$("#day").val(day);
	console.log("charis")
});