<!DOCTYPE html>
<html lang="en">
	<head>
        <meta charset="utf-8">
        <meta content="IE=edge" http-equiv="X-UA-Compatible">
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <title><?php echo e($title); ?> | Green and White 2018</title>

        <!-- FONTS -->
        <link href="https://fonts.googleapis.com/css?family=Barlow|Roboto|Roboto+Condensed" rel="stylesheet">
        <link href="<?php echo e(asset('css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/shapes.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/subscribe.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css">
    </head>

    <body>
        <?php echo $__env->yieldContent('content'); ?>
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/login.js')); ?>"></script>
        <script src="<?php echo e(asset('js/parallax.min.js')); ?>js/parallax.min.js"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    </body>
</html>