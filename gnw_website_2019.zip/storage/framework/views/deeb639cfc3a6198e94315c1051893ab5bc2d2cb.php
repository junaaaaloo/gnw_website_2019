<?php $__env->startSection('stylesheets'); ?>
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.green.css')); ?>" id="theme-stylesheet">
<link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<li>
    <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i><span>Home</span></a>
</li>
<li>
    <a href="<?php echo e(route('sub.basic')); ?>"><i class="fa fa-user"></i><span>Basic Information</span></a>
</li>
<li class="active">
    <a href="<?php echo e(route('sub.payment')); ?>"><i class="fa fa-credit-card"></i><span>Payment Information</span></a>
</li>
<li>
    <a href="<?php echo e(route('sub.affiliations')); ?>"><i class="fa fa-star"></i><span>Affiliations</span></a>
</li>
<li>
    <a href="<?php echo e(route('sub.writeup')); ?>"><i class="fa fa-pencil-square-o"></i><span>Write Up</span></a>
</li>
<li>
    <a href="<?php echo e(route('sched.pictorial')); ?>"><i class="fa fa-calendar-check-o"></i><span>Schedule Pictorial &nbsp; 
        <span class="badge badge-primary">Coming Soon</span></span></a>
</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="updates section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h2 class="h5 display display">Payment Information</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">   
                            <div class="row">
                                <div class="col-lg-4">
                                    <label for="idn">Yearbook</label>
                                    <?php switch($payment->yearbookStatus):
                                        case (1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Paid<br>
                                                OR: <?php echo e($payment->yearbookOR); ?><br>
                                                <?php if($payment->isPartial === "yes"): ?>
                                                    Is Partial: Yes
                                                <?php else: ?>
                                                    Is Partial: No
                                                <?php endif; ?>
                                                <br>
                                                Partial OR: <?php echo e($payment->partialOR); ?>

                                            </div>
                                            <input type="text" class="form-control" placeholder="Yearbook OR" disabled required><br>
                                            <form method="POST" action="<?php echo e(route('payment.submit.yearbook')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <?php if($payment->isPartial === "yes"): ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial" checked>Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR">
                                                <?php else: ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial">Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR" disabled>
                                                <?php endif; ?>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>

                                        <?php case (-1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Not Paid<br>
                                                OR: <?php echo e($payment->yearbookOR); ?><br>
                                                <?php if($payment->isPartial === "yes"): ?>
                                                    Is Partial: Yes
                                                <?php else: ?>
                                                    Is Partial: No
                                                <?php endif; ?>
                                                <br>
                                                Partial OR: <?php echo e($payment->partialOR); ?>

                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.yearbook')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Yearbook OR" name="yearbookOR" required>
                                                <br>
                                                <?php if($payment->isPartial === "yes"): ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial" checked>Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR">
                                                <?php else: ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial">Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR" disabled>
                                                <?php endif; ?>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>

                                        <?php case (0): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Pending<br>
                                                OR: <?php echo e($payment->yearbookOR); ?><br>
                                                <?php if($payment->isPartial === "yes"): ?>
                                                    Is Partial: Yes
                                                <?php else: ?>
                                                    Is Partial: No
                                                <?php endif; ?>
                                                <br>
                                                Partial OR: <?php echo e($payment->partialOR); ?>

                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.yearbook')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Yearbook OR" name="yearbookOR" value="<?php echo e($payment->yearbookOR); ?>">
                                                <br>
                                                <?php if($payment->isPartial === "yes"): ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial" checked>Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR">
                                                <?php else: ?>
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="checkbox" name="isPartial" value="partial">Is this a partial payment?
                                                </label>
                                                <input type="text" class="form-control" placeholder="Partial OR" name="partialOR" disabled>
                                                <?php endif; ?>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </div>
                                <div class="col-lg-4">
                                    <label for="nde">Photo</label>
                                    <?php switch($payment->photoStatus):
                                        case (1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Paid<br>
                                                OR: <?php echo e($payment->photoOR); ?><br>
                                                <?php if($payment->photoPackage === "a"): ?>
                                                Photo Package: Package A
                                                <?php elseif($payment->photoPackage === "b"): ?>
                                                Photo Package: Package B
                                                <?php elseif($payment->photoPackage === "c"): ?>
                                                Photo Package: Package C
                                                <?php elseif($payment->photoPackage === "d"): ?>
                                                Photo Package: Package D
                                                <?php else: ?>
                                                Photo Package:
                                                <?php endif; ?>
                                            </div>
                                            <input type="text" class="form-control" placeholder="Photo OR" disabled required>
                                            <form method="POST" action="<?php echo e(route('payment.submit.photo')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <select class="form-control" id="package" name="package" required>
                                                    <?php if($payment->photoPackage === "a"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a" selected>Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "b"): ?>
                                                    <option disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b" selected>Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "c"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c" selected>Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "d"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d" selected>Package D</option>
                                                    <?php else: ?>
                                                    <option value="" disabled selected>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php endif; ?>
                                                </select>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>

                                        <?php case (-1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Not Paid<br>
                                                OR: <?php echo e($payment->photoOR); ?><br>
                                                <?php if($payment->photoPackage === "a"): ?>
                                                Photo Package: Package A
                                                <?php elseif($payment->photoPackage === "b"): ?>
                                                Photo Package: Package B
                                                <?php elseif($payment->photoPackage === "c"): ?>
                                                Photo Package: Package C
                                                <?php elseif($payment->photoPackage === "d"): ?>
                                                Photo Package: Package D
                                                <?php else: ?>
                                                Photo Package:
                                                <?php endif; ?>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.photo')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Photo OR" name="photoOR" required>
                                                <select class="form-control" id="package" name="package" required>
                                                    <?php if($payment->photoPackage === "a"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a" selected>Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "b"): ?>
                                                    <option disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b" selected>Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "c"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c" selected>Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "d"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d" selected>Package D</option>
                                                    <?php else: ?>
                                                    <option value="" disabled selected>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php endif; ?>
                                                </select>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>

                                        <?php case (0): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Pending<br>
                                                OR: <?php echo e($payment->photoOR); ?><br>
                                                <?php if($payment->photoPackage === "a"): ?>
                                                Photo Package: Package A
                                                <?php elseif($payment->photoPackage === "b"): ?>
                                                Photo Package: Package B
                                                <?php elseif($payment->photoPackage === "c"): ?>
                                                Photo Package: Package C
                                                <?php elseif($payment->photoPackage === "d"): ?>
                                                Photo Package: Package D
                                                <?php else: ?>
                                                Photo Package:
                                                <?php endif; ?>
                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.photo')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Photo OR" name="photoOR" value="<?php echo e($payment->photoOR); ?>" required>
                                                <select class="form-control" id="package" name="package" required>
                                                    <?php if($payment->photoPackage === "a"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a" selected>Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "b"): ?>
                                                    <option disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b" selected>Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "c"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c" selected>Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php elseif($payment->photoPackage === "d"): ?>
                                                    <option value="" disabled>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d" selected>Package D</option>
                                                    <?php else: ?>
                                                    <option value="" disabled selected>Photo Package</option>
                                                    <option value="a">Package A</option>
                                                    <option value="b">Package B</option>
                                                    <option value="c">Package C</option>
                                                    <option value="d">Package D</option>
                                                    <?php endif; ?>
                                                </select>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </div>
                                <div class="col-lg-4">
                                    <label for="nde">Delivery</label>
                                    <?php switch($payment->deliveryStatus):
                                        case (1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Paid<br>
                                                OR: <?php echo e($payment->deliveryOR); ?>

                                            </div>
                                            <input type="text" class="form-control" placeholder="Delivery OR" disabled required>
                                            <br>
                                            <button class="btn btn-block btn-success" disabled>Update</button>
                                            <?php break; ?>

                                        <?php case (-1): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Not Paid<br>
                                                OR: <?php echo e($payment->deliveryOR); ?>

                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.delivery')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Delivery OR" name="deliveryOR" required>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>

                                        <?php case (0): ?>
                                            <div class="alert alert-primary" role="alert">
                                                Status: Pending<br>
                                                OR: <?php echo e($payment->deliveryOR); ?>

                                            </div>
                                            <form method="POST" action="<?php echo e(route('payment.submit.delivery')); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="text" class="form-control" placeholder="Delivery OR" name="deliveryOR" value="<?php echo e($payment->deliveryOR); ?>" required>
                                                <br>
                                                <button type="submit" class="btn btn-block btn-success">Update</button>
                                            </form>
                                            <?php break; ?>
                                    <?php endswitch; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/grasp_mobile_progress_circle-1.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/front.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>