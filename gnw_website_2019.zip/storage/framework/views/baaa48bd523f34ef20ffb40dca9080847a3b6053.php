<?php $__env->startSection('content'); ?>
<div class="container main">
    <div class="loginrow">
        <div class="done-section" id="loginDiv">
            <div class="header text-right" id="back">
                <a href="<?php echo e(route('index')); ?>"><span class="back text-right"><span class="fa fa-angle-left"></span>&nbsp; Back</span></a>
            </div>
            <hr/>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="lbl" for="inputID">ID Number</label>
                    <input type="text" class="form-control" id="inputID" name="idnum" aria-describedby="emailHelp" placeholder="e.g 11245678">
                    <small id="emailHelp" class="form-text text-muted">Follows DLSU ID format</small>
                </div>

                <div class="form-group">
                    <label class="lbl" for="inputPW">Password</label>
                    <input type="password" class="form-control" id="inputPW" name="password" placeholder="Password">
                </div>
                <div class="form-check">
                    <a href="<?php echo e(route('password.request')); ?>" class="forgot">Forgot Password?</a>
                </div>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    Incorrect ID Number and/or Password
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-block btn-success">Login</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logsub', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>