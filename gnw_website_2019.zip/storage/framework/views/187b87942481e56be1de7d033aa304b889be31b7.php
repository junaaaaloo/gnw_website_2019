<?php $__env->startSection('content'); ?>
<div class="container main">
    <div class="loginrow">
        <div class="sub-section">
            <h3 class="sub-head">Green &amp; White 2018 &nbsp;|&nbsp; <span class="sub-text">Subscribe</span></h3>
            <hr/>
            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    <div class="col-lg-4">
                        <input type="text" class="form-control" placeholder="First name" name="firstname" required>
                    </div>
                    <div class="col-lg-4">
                        <input type="text" class="form-control" placeholder="Middle name" name="middlename">
                    </div>
                    <div class="col-lg-4">
                        <input type="text" class="form-control" placeholder="Last name" name="lastname" required>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-sm-6">
                        <input type="text" class="form-control" placeholder="DLSU Email" name="email" required>
                    </div>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" placeholder="Non-DLSU Email" name="nondlsu" required>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-sm-4">
                        <input type="text" class="form-control" placeholder="ID Number" name="idnum" id="idnum" required>
                    </div>
                    <div class="col-sm-8">
                        <input type="hidden" name="isVerified" id="isVerified" required>
                        <button type="button" class="btn btn-success" id="checkid">Check ID Number</button>
                        &nbsp;&nbsp;
                        <span class="fa fa-check verified invisible" id="verifyText">&nbsp;<span class="v-text">Verified</span></span>
                        <span class="fa fa-close notverified invisible" id="notverifyText">&nbsp;<span class="v-text">Not Verified</span></span>
                    </div>
                </div><br>
                <div class="row">
                    <div class="col-sm-6">
                        <input type="password" class="form-control" placeholder="Password" name="password" required>
                    </div>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation" required>
                    </div>
                </div><br>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        - <?php echo e($error); ?><br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <hr/>
                <div class="d-flex flex-row-reverse">
                    <div class="p-2">
                        <button type="submit" class="btn btn-primary btn-md">Subscribe &nbsp;<span class="fa fa-paper-plane"></span></button>
                    </div>
                    <div class="p-2">
                        <button onclick="window.location.href='<?php echo e(route('index')); ?>'" type="button" class="btn btn-secondary btn-md">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logsub', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>