<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta content="IE=edge" http-equiv="X-UA-Compatible">
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <title>Green &amp; White 2018</title>

        <!-- FONTS -->
        <link href="https://fonts.googleapis.com/css?family=Barlow|Roboto|Roboto+Condensed" rel="stylesheet">

        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/shapes.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css">
    </head>

    <body data-spy="scroll">
        <section class="section-main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-5 main">
                        <div class="head">
                            <img class="img-responsive main-logo" src="<?php echo e(asset('img/vertical-logo.png')); ?>">

                            <h1 class="name-head wow fadeInUp delay-02s">CAPTURING IMAGES</h1>
                            <h1 class="name-head wow fadeInUp delay-02s">OF LASALLIAN</h1>
                            <h1 class="name-head wow fadeInUp delay-02s">EXCELLENCE</h1>
                            <br><br>
                            <button onclick="window.location.href='<?php echo e(route('login')); ?>'" id="login" class="be-sub login" type="button">LOG IN</button>
                            <button onclick="window.location.href='<?php echo e(route('register')); ?>'" class="be-sub" type="button">BE A SUBSCRIBER</button>
                        </div>
                    </div>
                    <div class="col-sm-7">
                         <div class="shapes scene" id="scene">
                            <div class="layer" data-depth="0.8">
                                <img class="img-responsive pent pent-dark-bot" src="<?php echo e(asset('img/pentagon-dark.png')); ?>">
                                <img class="img-responsive pent pent-light-bot" src="<?php echo e(asset('img/pentagon-light.png')); ?>">
                                <img class="img-responsive pent pent-mid-bot" src="<?php echo e(asset('img/pentagon-mid.png')); ?>">
                                <img class="img-responsive pent pent-dark-top" src="<?php echo e(asset('img/pentagon-dark.png')); ?>">
                                <img class="img-responsive pent pent-light-top" src="<?php echo e(asset('img/pentagon-light.png')); ?>">
                                <img class="img-responsive pent pent-mid-top" src="<?php echo e(asset('img/pentagon-mid.png')); ?>">
                            </div>

                            <div class="layer" data-depth="0.6">
                                <img class="img-responsive pent pent-outline-bot" src="<?php echo e(asset('img/pentagon-outline.png')); ?>">
                                <img class="img-responsive pent pent-outline-bot-1" src="<?php echo e(asset('img/pentagon-outline.png')); ?>">
                                <img class="img-responsive pent pent-outline-bot-3" src="<?php echo e(asset('img/pentagon-outline.png')); ?>">
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </section>

        <section class="section-blank">
            <h1 class="section-blank-text">Be a <span class="section-blank-text part">part</span> of the</h1>
            <h1 class="section-blank-text"><span class="section-blank-text part">Green &amp; White 2018 Yearbook</span></h1>
            <h1 class="section-blank-text">Join the Journey!</h1>
        </section>

        <section class="feature-section">
            <div class="width50"><img alt="..." src="<?php echo e(asset('img/Shape-10-copy.png')); ?>"></div>
            <div class="container">
                <div class="feature-content">
                    <img alt="1" class="img-responsive stepnum" src="<?php echo e(asset('img/steps/1.png')); ?>">
                    <div class="feature-text">
                        <h1 class="steph1">Registration</h1>
                        <p class="step-desc">Initial process for becoming a subscriber of Green &amp; White, the official DLSU Yearbook</p>
                    </div>
                </div>
            </div>
            <div class="width50"><img alt="..." src="<?php echo e(asset('img/Shape-2.png')); ?>"></div>
            <div class="container clearfix">
                <div class="feature-content col-sm-6 float-right">
                    <img alt="2" class="img-responsive stepnum" src="<?php echo e(asset('img/steps/2.png')); ?>">
                    <div class="feature-text">
                        <h1 class="steph1">Settling of Accounts</h1>
                        <p class="step-desc">Paying your Green &amp; White fees in order to settle your accounts and avoid further issues that may arise</p>
                    </div>
                </div>
            </div>
            <div class="width50"><img alt="..." src="<?php echo e(asset('img/Shape-3.png')); ?>"></div>
            <div class="container">
                <div class="feature-content">
                    <img alt="3" class="img-responsive stepnum" src="<?php echo e(asset('img/steps/3.png')); ?>">
                    <div class="feature-text">
                        <h1 class="steph1">Pictorial</h1>
                        <p class="step-desc">Choose from the different timeslots offered to you depending on your college. After Scheduling your Graduation Pictorial and being present on the assigned date to have your photos taken</p>
                    </div>
                </div>
            </div>
            <div class="width50"><img alt="..." src="<?php echo e(asset('img/Shape-4.png')); ?>"></div>
            <div class="container clearfix">
                <div class="feature-content col-sm-6 float-right">
                    <img alt="4" class="img-responsive stepnum" src="<?php echo e(asset('img/steps/4.png')); ?>">
                    <div class="feature-text">
                        <h1 class="steph1">Claiming of Photos</h1>
                        <p class="step-desc">Once the printing of all subscriber's photos, you may claim them on release</p>
                    </div>
                </div>
            </div>
            <div class="width50"><img alt="..." src="<?php echo e(asset('img/Shape-3.png')); ?>"></div>
            <div class="container">
                <div class="feature-content">
                    <img alt="5" class="img-responsive stepnum" src="<?php echo e(asset('img/steps/5.png')); ?>">
                    <div class="feature-text">
                        <h1 class="steph1">Claiming of Yearbook</h1>
                        <p class="step-desc">After a year-long process for the Green &amp; White, wait for your yearbook to be delivered to said delivery addresses of our subscribers</p>
                    </div>
                </div>
            </div>
        </section>

        <footer class="section-footer">
            <img class="img-responsive footer-logo" src="<?php echo e(asset('img/logo-footer.png')); ?>">
            <h5 class="footer-text">Green &amp; White 2018 &copy; All Rights Reserved 2017</h5>
        </footer>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"> </script>
        <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/parallax.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/index.js')); ?>"></script>
        <script src="<?php echo e(asset('js/wow.min.js')); ?>"></script>
        <script>
            new WOW().init();
        </script>
    </body>
</html>