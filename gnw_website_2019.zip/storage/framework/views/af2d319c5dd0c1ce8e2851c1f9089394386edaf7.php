<?php $__env->startSection('content'); ?>
<div class="container main">
    <div class="loginrow">
        <div class="done-section" id="forgotDiv">
            <div class="header text-right" id="back">
                <a href="<?php echo e(route('home')); ?>"><span class="back text-right"><span class="fa fa-angle-left"></span>&nbsp; Back</span></a>
            </div>
            <hr/>
            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="lbl" for="inputID">ID Number</label>
                    <input type="text" class="form-control" id="inputID" name="idnum" aria-describedby="emailHelp" placeholder="e.g 11245678" required>
                    <small id="emailHelp" class="form-text text-muted">An email will be sent to you shortly</small>
                </div>
                <?php if(Session::has('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('status')); ?>

                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger" role="alert">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($errors); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-block btn-success">Send me an email</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.logsub', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>