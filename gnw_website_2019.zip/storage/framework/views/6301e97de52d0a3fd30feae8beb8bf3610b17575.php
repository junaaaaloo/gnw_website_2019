<?php $__env->startSection('stylesheets'); ?>
<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/fontastic.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css')); ?>">
<link href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/style.green.css')); ?>" id="theme-stylesheet">
<link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('css/admindb.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<li>
	<a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i><span>Home</span></a>
</li>
<li> 
    <a href="#sub-list" data-toggle="collapse" aria-expanded="false"><i class="fa fa-users"></i><span>Subscriber</span>
    <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
    <ul id="sub-list" class="collapse list-unstyled">
        <li> <a href="<?php echo e(route('admin.manage.regid')); ?>">Manage Registered IDs</a></li>
        <li> <a href="<?php echo e(route('admin.manage.subs')); ?>">Manage Subscribers</a></li>
        <li class="active"> <a href="<?php echo e(route('admin.manage.payments')); ?>">Manage Payment</a></li>
        <li> <a href="<?php echo e(route('admin.manage.pictorial')); ?>">Manage Pictorial</a></li>
    </ul>
</li>
<li> 
    <a href="#announcement-list" data-toggle="collapse" aria-expanded="false"><i class="fa fa-paper-plane-o"></i><span>News</span>
    <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
    <ul id="announcement-list" class="collapse list-unstyled">
        <li> <a href="<?php echo e(route('admin.create')); ?>">Add News</a></li>
        <li> <a href="<?php echo e(route('admin.manage.news')); ?>">Manage News</a></li>
    </ul>
</li>
<?php if($role === "Administrator"): ?>
<li> 
    <a href="#admin-list" data-toggle="collapse" aria-expanded="false"><i class="fa fa-group"></i><span>Admin</span>
    <div class="arrow pull-right"><i class="fa fa-angle-down"></i></div></a>
    <ul id="admin-list" class="collapse list-unstyled">
        <li> <a href="<?php echo e(route('admin.manage.admin')); ?>">Manage Admin Accounts</a></li>
    </ul>
</li>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="dashboard-header section-padding">
    <div class="container-fluid">
        <h1>Manage Payment</h1>
        <small class="form-text text-muted">Data with Red Highlight have the "Pending" status and data with Gray highlight have the "Not Paid" status. <br>If the data with the "Not Paid" status have an OR, it means that the input OR of the user have been rejected.</small>
        <br>
        <table id="paymentTable" class="table table-bordered" cellspacing="0" width="100%">
            <thead class="table-dark">
                <tr>
                    <th>ID Number</th>
                    <th>Yearbook OR</th>
                    <th>Partial Payment</th>
                    <th>Photo OR</th>
                    <th>Photo Package</th>
                    <th>Delivery OR</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="payment-row" data-id="<?php echo $payment->idnum; ?>" data-ybstatus="<?php echo $payment->yearbookStatus; ?>" data-pstatus="<?php echo $payment->photoStatus; ?>" data-dstatus="<?php echo $payment->deliveryStatus; ?>">
                    <td><?php echo $payment->idnum; ?></td>
                    <?php if($payment->yearbookStatus === 0): ?>
                        <td class="payment-pending"><?php echo $payment->yearbookOR; ?></td>
                    <?php elseif($payment->yearbookStatus === -1): ?>
                        <td class="payment-none"><?php echo $payment->yearbookOR; ?></td>
                    <?php else: ?>
                        <td><?php echo $payment->yearbookOR; ?></td>
                    <?php endif; ?>

                    <?php if($payment->isPartial === "yes"): ?>
                        <td>Yes</td>
                    <?php elseif($payment->isPartial === "no"): ?>
                        <td>No</td>
                    <?php else: ?>
                        <td>-</td>
                    <?php endif; ?>

                    <?php if($payment->photoStatus === 0): ?>
                        <td class="payment-pending"><?php echo $payment->photoOR; ?></td>
                    <?php elseif($payment->photoStatus === -1): ?>
                        <td class="payment-none"><?php echo $payment->photoOR; ?></td>
                    <?php else: ?>
                        <td><?php echo $payment->photoOR; ?></td>
                    <?php endif; ?>

                    <?php if($payment->photoPackage === "a" || $payment->photoPackage === "b" || $payment->photoPackage === "c"): ?>
                        <td><?php echo $payment->photoPackage; ?></td>
                    <?php else: ?>
                        <td>-</td>
                    <?php endif; ?>

                    <?php if($payment->deliveryStatus === 0): ?>
                        <td class="payment-pending"><?php echo $payment->deliveryOR; ?></td>
                    <?php elseif($payment->deliveryStatus === -1): ?>
                        <td class="payment-none"><?php echo $payment->deliveryOR; ?></td>
                    <?php else: ?>
                        <td><?php echo $payment->deliveryOR; ?></td>
                    <?php endif; ?>
                    
                    <?php switch($payment->status):
                        case (1): ?>
                            <td>Paid</td>
                            <?php break; ?>

                        <?php case (-1): ?>
                            <td>Not Paid</td>
                            <?php break; ?>

                        <?php case (0): ?>
                            <td>Partial</td>
                            <?php break; ?>
                    <?php endswitch; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</section>

<div class="modal fade" tabindex="-1" role="dialog" id="paymentsModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Payment Status</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form method="POST" action="<?php echo e(route('payment.status.update')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="form-group row">
                        <label for="ybstatus" class="col-sm-2 col-form-label">Yearbook</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="yearbookStatus" id="ybstatus">
                                <option value="1">Paid</option>
                                <option value="0" disabled="true">Pending</option>
                                <option value="-1">Not Paid</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="pstatus" class="col-sm-2 col-form-label">Photo</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="photoStatus" id="pstatus">
                                <option value="1">Paid</option>
                                <option value="0" disabled="true">Pending</option>
                                <option value="-1">Not Paid</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="dstatus" class="col-sm-2 col-form-label">Delivery</label>
                        <div class="col-sm-10">
                            <select class="form-control" name="deliveryStatus" id="dstatus">
                                <option value="1">Paid</option>
                                <option value="0" disabled="true">Pending</option>
                                <option value="-1">Not Paid</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="idnum" id="idnum">
                    <button type="submit" class="btn btn-primary">Update Status</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascripts'); ?>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"> </script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/grasp_mobile_progress_circle-1.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/front.js')); ?>"></script>
<script src="<?php echo e(asset('js/admindb.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>