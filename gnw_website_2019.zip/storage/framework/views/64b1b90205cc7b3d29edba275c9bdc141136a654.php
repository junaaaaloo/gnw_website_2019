<?php $__env->startSection('content'); ?>
<div class="container main">
    <div class="loginrow">
        <div class="done-section" id="forgotDiv">
            <div class="header text-right" id="back">
                <a href="<?php echo e(route('home')); ?>"><span class="back text-right"><span class="fa fa-angle-left"></span>&nbsp; Back</span></a>
            </div>
            <hr/>
            <form class="form-horizontal" method="POST" action="<?php echo e(route('password.request')); ?>">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="token" value="<?php echo e($token); ?>">

                <div class="form-group">
                    <label class="lbl" for="idnum">ID Number</label>
                    <input id="idnum" type="text" class="form-control" name="idnum" required autofocus="">
                    <?php if($errors->has('idnum')): ?>
                        <small id="emailHelp" class="form-text text-muted">
                            <?php echo e($errors->first('idnum')); ?>

                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label class="lbl" for="inputID">Password</label>
                    <input id="password" type="password" class="form-control" name="password" required>
                    <?php if($errors->has('password')): ?>
                        <small id="emailHelp" class="form-text text-muted">
                            <?php echo e($errors->first('password')); ?>

                        </small>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label class="lbl" for="inputID">Confirm Password</label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                    <?php if($errors->has('password_confirmation')): ?>
                        <small id="emailHelp" class="form-text text-muted">
                            <?php echo e($errors->first('password_confirmation')); ?>

                        </small>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-block btn-success">Reset Password</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.logsub', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>